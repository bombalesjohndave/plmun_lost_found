<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';

verify_csrf();
$error = '';
$already_registered = false;
$allowed_domain = 'plmun.edu.ph';
$name = $email = $student_id = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $student_id = trim($_POST['student_id'] ?? '');
    $password = $_POST['password'] ?? '';
    $domain = substr(strrchr($email, '@') ?: '', 1);

    if (
        $name === '' ||
        !filter_var($email, FILTER_VALIDATE_EMAIL) ||
        strlen($password) < 8
    ) {
        $error = 'Enter your name, and a password with at least 8 characters.';
    } elseif ($domain !== $allowed_domain) {
        $error = 'Only PLMun school emails (@plmun.edu.ph) can register.';
    } else {
        $chk = $pdo->prepare('SELECT 1 FROM users WHERE school_email = ? LIMIT 1');
        $chk->execute([$email]);
        if ($chk->fetchColumn()) {
            $error = 'This email is already registered.';
            $already_registered = true;
        }
        if (!$error && $student_id !== '') {
            $chk = $pdo->prepare('SELECT 1 FROM users WHERE student_id = ? LIMIT 1');
            $chk->execute([$student_id]);
            if ($chk->fetchColumn()) {
                $error = 'This Student ID is already registered.';
                $already_registered = true;
            }
        }
        if (!$error) {
            try {
                $stmt = $pdo->prepare(
                    "INSERT INTO users (
                        full_name,
                        school_email,
                        student_id,
                        password_hash,
                        role
                    ) VALUES (?, ?, ?, ?, 'user')"
                );
                $stmt->execute([
                    $name,
                    $email,
                    $student_id ?: null,
                    password_hash($password, PASSWORD_DEFAULT)
                ]);
                header('Location: login.php?registered=1');
                exit;
            } catch (PDOException $e) {
                if ($e->getCode() === '23000') {
                    $error = 'This email or Student ID is already registered.';
                    $already_registered = true;
                } else {
                    $error = 'Something went wrong. Please try again.';
                }
            }
        }
    }
}
$page_title = 'Create account';
require __DIR__ . '/includes/header.php';
?>
<div class="auth-wrap">
    <form class="card form-card" method="post">
        <?= csrf_field() ?>
        <h1>Create account</h1>
        <p class="muted">
            Register with your PLMun school account details.
        </p>
        <?php if ($error): ?>
            <div class="alert error">
                <?= h($error) ?>
            </div>
        <?php endif; ?>
        <label>
            Full name
            <input
                name="name"
                required
                autocomplete="name"
                placeholder="Enter you full name"
            >
        </label>
        <label>
            School email
            <input
                type="email"
                name="email"
                required
                autocomplete="email"
                placeholder="e.g. fullname_program@plmun.edu.ph"
            >
        </label>
        <label>
            Student ID
            <input name="student_id" placeholder="e.g. 25177734">
        </label>
        <label>
            Password
           <span class="password-field">
                <input
                type="password"
                name="password"
                required
                autocomplete="current-password"
                placeholder="Your Password"
            >
            <button type="button" class="toggle-password" aria-label="Show password" aria-pressed="false">Show</button>
            </span>
        </label>
        <button class="btn full">
            Create account
        </button>
        <p class="muted center">
            Already registered?
            <a href="login.php">Log in</a>
        </p>
    </form>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
