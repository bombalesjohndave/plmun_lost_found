// Hamburger menu
const menuToggle = document.getElementById('menuToggle');
const sideNav = document.getElementById('sidenav');
const navOverlay = document.getElementById('navOverlay');

function setNav(open) {
    if (!sideNav) return;

    sideNav.classList.toggle('open', open);
    navOverlay.hidden = !open;
    menuToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    sideNav.setAttribute('aria-hidden', open ? 'false' : 'true');
    document.body.classList.toggle('nav-open', open);
}

if (menuToggle && sideNav) {
    menuToggle.addEventListener('click', () => setNav(!sideNav.classList.contains('open')));
    navOverlay.addEventListener('click', () => setNav(false));

    document.addEventListener('keydown', e => {
        if (e.key === 'Escape') setNav(false);
    });
}

// Forms: optional confirm dialog (data-confirm) and double-click protection
document.querySelectorAll('form').forEach(form => {
    form.addEventListener('submit', event => {
        const msg = form.dataset.confirm;

        if (msg && !confirm(msg)) {
            event.preventDefault();
            return;
        }

        const button = event.submitter || form.querySelector('button[type="submit"], button:not([type])');

        if (button && form.checkValidity()) {
            // Disable after the browser has collected the form data, so the button's value is still sent.
            setTimeout(() => {
                button.textContent = 'Please wait\u2026';
                button.disabled = true;
            }, 0);
        }
    });
});

// Keep what the user typed if the page is refreshed (forms marked with data-autosave)
document.querySelectorAll('form[data-autosave]').forEach(form => {
    const key = 'autosave:' + form.dataset.autosave;

    if (document.querySelector('[data-clear-autosave]')) {
        sessionStorage.removeItem(key);
    }

    let saved = {};

    try {
        saved = JSON.parse(sessionStorage.getItem(key) || '{}');
    } catch (e) { }

    const fields = [...form.elements].filter(el =>
        el.name &&
        el.name !== 'csrf_token' &&
        !['file', 'password', 'hidden', 'submit', 'button'].includes(el.type)
    );

    fields.forEach(el => {
        if (!(el.name in saved)) return;

        if (el.type === 'radio') {
            el.checked = el.value === saved[el.name];
        } else if (el.type === 'checkbox') {
            el.checked = !!saved[el.name];
        } else {
            el.value = saved[el.name];
        }
    });

    const save = () => {
        const d = {};

        fields.forEach(el => {
            if (el.type === 'radio') {
                if (el.checked) d[el.name] = el.value;
            } else if (el.type === 'checkbox') {
                d[el.name] = el.checked;
            } else {
                d[el.name] = el.value;
            }
        });

        try {
            sessionStorage.setItem(key, JSON.stringify(d));
        } catch (e) { }
    };

    form.addEventListener('input', save);
    form.addEventListener('change', save);
});

// Notification dropdown
const bellBtn = document.getElementById('bellBtn');
const notifPanel = document.getElementById('notifPanel');
function setPanel(open) {
  if (!notifPanel) return;
  notifPanel.hidden = !open;
  bellBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
  if (open) setNav(false);
}
if (bellBtn && notifPanel) {
  bellBtn.addEventListener('click', e => { e.stopPropagation(); setPanel(notifPanel.hidden); });
  document.addEventListener('click', e => { if (!notifPanel.hidden && !notifPanel.contains(e.target)) setPanel(false); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') setPanel(false); });
}
if (menuToggle) menuToggle.addEventListener('click', () => { if (notifPanel) notifPanel.hidden = true; });

// Show / hide password
document.querySelectorAll('.toggle-password').forEach(btn => {
  btn.addEventListener('click', () => {
    const input = btn.parentElement.querySelector('input');
    const show = input.type === 'password';
    input.type = show ? 'text' : 'password';
    btn.textContent = show ? 'Hide' : 'Show';
    btn.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
    btn.setAttribute('aria-pressed', show ? 'true' : 'false');
  });
});
