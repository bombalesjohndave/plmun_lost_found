<?php
require_once __DIR__ . '/includes/auth.php';

require_login();
verify_csrf();

$_SESSION = [];
session_destroy();

header('Location: index.php');
exit;
