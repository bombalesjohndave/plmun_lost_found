CREATE DATABASE IF NOT EXISTS plmun_lost_found CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE plmun_lost_found;

CREATE TABLE users (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(150) NOT NULL,
    school_email VARCHAR(190) NOT NULL UNIQUE,
    student_id VARCHAR(60) NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') NOT NULL DEFAULT 'user',
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE = InnoDB;

CREATE TABLE item_reports (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    reporter_id BIGINT UNSIGNED NOT NULL,
    item_name VARCHAR(150) NOT NULL,
    category VARCHAR(80) NOT NULL,
    description TEXT NOT NULL,
    location_found VARCHAR(180) NOT NULL,
    date_found DATE NOT NULL,
    custody_status ENUM('Reporter', 'Admin') NOT NULL DEFAULT 'Admin',
    report_status ENUM(
        'Draft',
        'Under Review',
        'Published',
        'Rejected',
        'Returned'
    ) NOT NULL DEFAULT 'Under Review',
    photo_path VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_report_user FOREIGN KEY (reporter_id) REFERENCES users(id)
) ENGINE = InnoDB;

CREATE TABLE claims (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    item_report_id BIGINT UNSIGNED NOT NULL,
    claimant_id BIGINT UNSIGNED NOT NULL,
    last_seen_location TEXT NOT NULL,
    last_seen_time VARCHAR(150) NOT NULL,
    remembered_details TEXT NOT NULL,
    status ENUM(
        'Pending Review',
        'Under Verification',
        'Additional Information Required',
        'Approved',
        'Rejected',
        'Unresolved / On Hold'
    ) NOT NULL DEFAULT 'Pending Review',
    reviewed_by BIGINT UNSIGNED NULL,
    reviewed_at DATETIME NULL,
    decision_reason TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_claim_item FOREIGN KEY (item_report_id) REFERENCES item_reports(id),
    CONSTRAINT fk_claim_user FOREIGN KEY (claimant_id) REFERENCES users(id),
    CONSTRAINT fk_claim_admin FOREIGN KEY (reviewed_by) REFERENCES users(id)
) ENGINE = InnoDB;

CREATE TABLE item_custody_records (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    item_report_id BIGINT UNSIGNED NOT NULL,
    from_custodian ENUM('Reporter', 'Admin') NULL,
    to_custodian ENUM('Reporter', 'Admin') NOT NULL,
    recorded_by BIGINT UNSIGNED NOT NULL,
    notes TEXT NULL,
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (item_report_id) REFERENCES item_reports(id),
    FOREIGN KEY (recorded_by) REFERENCES users(id)
) ENGINE = InnoDB;

CREATE TABLE chat_conversations (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    item_report_id BIGINT UNSIGNED NOT NULL,
    claim_id BIGINT UNSIGNED NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (item_report_id) REFERENCES item_reports(id),
    FOREIGN KEY (claim_id) REFERENCES claims(id)
) ENGINE = InnoDB;

CREATE TABLE chat_participants (
    conversation_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    PRIMARY KEY (conversation_id, user_id),
    FOREIGN KEY (conversation_id) REFERENCES chat_conversations(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE = InnoDB;

CREATE TABLE chat_messages (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    conversation_id BIGINT UNSIGNED NOT NULL,
    sender_id BIGINT UNSIGNED NOT NULL,
    message TEXT NOT NULL,
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    read_at DATETIME NULL,
    FOREIGN KEY (conversation_id) REFERENCES chat_conversations(id),
    FOREIGN KEY (sender_id) REFERENCES users(id)
) ENGINE = InnoDB;

CREATE TABLE notifications (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    title VARCHAR(180) NOT NULL,
    body TEXT NOT NULL,
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE = InnoDB;

CREATE TABLE item_release_records (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    item_report_id BIGINT UNSIGNED NOT NULL,
    claim_id BIGINT UNSIGNED NOT NULL,
    approved_by BIGINT UNSIGNED NOT NULL,
    released_to BIGINT UNSIGNED NOT NULL,
    custody_at_release ENUM('Reporter', 'Admin') NOT NULL,
    release_notes TEXT NULL,
    released_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (item_report_id) REFERENCES item_reports(id),
    FOREIGN KEY (claim_id) REFERENCES claims(id),
    FOREIGN KEY (approved_by) REFERENCES users(id),
    FOREIGN KEY (released_to) REFERENCES users(id)
) ENGINE = InnoDB;

CREATE TABLE admin_activity_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    admin_id BIGINT UNSIGNED NOT NULL,
    action VARCHAR(120) NOT NULL,
    entity_type VARCHAR(80) NOT NULL,
    entity_id BIGINT UNSIGNED NOT NULL,
    details TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES users(id)
) ENGINE = InnoDB;

CREATE INDEX idx_reports_status ON item_reports(report_status);

CREATE INDEX idx_reports_category ON item_reports(category);

CREATE INDEX idx_claim_status ON claims(status);

-- Create an administrator only through a trusted setup process.
-- Do not add public admin-role selection to registration.