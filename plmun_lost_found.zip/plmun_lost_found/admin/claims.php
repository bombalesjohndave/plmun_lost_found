<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';

verify_csrf();
require_admin();

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $status = $_POST['status'] ?? '';
    $reason = trim($_POST['reason'] ?? '');

    $allowed = [
        'Under Verification',
        'Additional Information Required',
        'Approved',
        'Rejected',
        'Unresolved / On Hold'
    ];

    if (!in_array($status, $allowed, true)) {
        $error = 'Invalid status.';
    } else {
        $s = $pdo->prepare('SELECT c.*,r.item_name,r.reporter_id FROM claims c JOIN item_reports r ON r.id=c.item_report_id WHERE c.id=?');
        $s->execute([$id]);
        $c = $s->fetch();

        if (!$c) {
            $error = 'Claim not found.';
        } elseif ($status === 'Rejected' && $reason === '') {
            $error = 'Enter a reason when rejecting a claim.';
        } elseif ($status === 'Approved' && (function () use ($pdo, $c, $id) {
            $q = $pdo->prepare("SELECT (SELECT report_status FROM item_reports WHERE id=?) st,(SELECT COUNT(*) FROM claims WHERE item_report_id=? AND status='Approved' AND id<>?) n");
            $q->execute([$c['item_report_id'], $c['item_report_id'], $id]);
            $r = $q->fetch();

            return $r['st'] === 'Returned' || (int)$r['n'] > 0;
        })()) {
            $error = 'This item is already returned or another claim is already approved. Resolve that first.';
        } else {
            $u = $pdo->prepare('UPDATE claims SET status=?,decision_reason=?,reviewed_by=?,reviewed_at=NOW() WHERE id=? AND (status<>? OR COALESCE(decision_reason,\'\')<>?)');
            $u->execute([$status, $reason ?: null, current_user_id(), $id, $status, $reason]);

            if ($u->rowCount() === 0) {
                $error = 'Nothing changed: this claim already has that status and note.';
            } else {
                log_admin_action($pdo, 'Updated claim status', 'claim', $id, $status . ($reason ? ' — ' . $reason : ''));

                notify_user($pdo, (int)$c['claimant_id'], 'Claim status updated', 'Your claim for ' . $c['item_name'] . ' is now: ' . $status . '.');
                notify_user($pdo, (int)$c['reporter_id'], 'Claim status updated', 'A claim for your item ' . $c['item_name'] . ' is now: ' . $status . '.');

                header('Location: claims.php');
                exit;
            }
        }
    }
}

$claims = $pdo->query("SELECT c.*,u.full_name claimant,u.school_email,r.item_name,r.reporter_id,r.custody_status,r.photo_path,r.category,r.location_found,r.date_found FROM claims c JOIN users u ON u.id=c.claimant_id JOIN item_reports r ON r.id=c.item_report_id ORDER BY c.created_at DESC")->fetchAll();

$page_title = 'Review claims';

require __DIR__ . '/../includes/header.php';
?>

<section class="page-heading">
    <span class="eyebrow">ADMIN</span>
    <h1>Review ownership claims</h1>
    <p>Assess evidence and responses. Matching descriptions alone do not prove ownership.</p>
</section>

<?php if ($error): ?>
    <div class="alert error"><?= h($error) ?></div>
<?php endif; ?>

<div class="list-grid">
    <?php foreach ($claims as $c): ?>
        <article class="card claim-card">
            <div>
                <span class="pill">Claim #<?= (int)$c['id'] ?></span>

                <h3><?= h($c['item_name']) ?> · Item #<?= (int)$c['item_report_id'] ?></h3>

                <?php
                $ev = $pdo->prepare('SELECT * FROM claim_evidence WHERE claim_id=? ORDER BY created_at');
                $ev->execute([$c['id']]);
                $evidence = $ev->fetchAll();
                ?>
                <div class="claim-media">
                    <figure>
                        <figcaption>Item being claimed</figcaption>
                        <?php if (!empty($c['photo_path'])): ?>
                            <a href="/plmun_lost_found/<?= h($c['photo_path']) ?>" target="_blank"><img src="/plmun_lost_found/<?= h($c['photo_path']) ?>" alt="Reported item"></a>
                        <?php else: ?>
                            <div class="no-media">No photo was uploaded for this item.</div>
                        <?php endif; ?>
                    </figure>
                    <?php foreach ($evidence as $e): ?>
                        <figure>
                            <figcaption>Claimant's evidence</figcaption>
                            <?php if (strpos($e['mime_type'], 'image/') === 0): ?>
                                <a href="../evidence.php?id=<?= (int)$e['id'] ?>&amp;inline=1" target="_blank"><img src="../evidence.php?id=<?= (int)$e['id'] ?>&amp;inline=1" alt="Evidence from claimant"></a>
                            <?php else: ?>
                                <div class="no-media"><a class="text-link" href="../evidence.php?id=<?= (int)$e['id'] ?>&amp;inline=1" target="_blank"><?= h($e['original_name']) ?></a><br><small><?= number_format($e['file_size'] / 1024, 1) ?> KB</small></div>
                            <?php endif; ?>
                        </figure>
                    <?php endforeach; ?>
                    <?php if (!$evidence): ?>
                        <figure>
                            <figcaption>Claimant's evidence</figcaption>
                            <div class="no-media">The claimant did not upload evidence.</div>
                        </figure>
                    <?php endif; ?>
                </div>
                <p><strong>Item:</strong> <?= h($c['category']) ?> · found at <?= h($c['location_found']) ?> on <?= h($c['date_found']) ?></p>

                <p><strong>Claimant:</strong> <?= h($c['claimant']) ?> (<?= h($c['school_email']) ?>)</p>
                <p><strong>Current custody:</strong> <?= h($c['custody_status']) ?></p>
                <p><strong>Last seen:</strong> <?= nl2br(h($c['last_seen_location'])) ?> · <?= h($c['last_seen_time']) ?></p>
                <p><strong>Remembered details:</strong> <?= nl2br(h($c['remembered_details'])) ?></p>
                <p><strong>Status:</strong> <?= h($c['status']) ?></p>

                
                <?php if ($c['decision_reason']): ?>
                    <p><strong>Previous note:</strong> <?= h($c['decision_reason']) ?></p>
                <?php endif; ?>

            </div>

            <form method="post" class="status-form">
                <?= csrf_field() ?>

                <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">

                <label>
                    Verification status
                    <select name="status">
                        <?php foreach (['Under Verification', 'Additional Information Required', 'Approved', 'Rejected', 'Unresolved / On Hold'] as $v): ?>
                            <option <?= $c['status'] === $v ? 'selected' : '' ?>>
                                <?= h($v) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </label>

                <label>
                    Admin notes / rejection reason
                    <textarea name="reason" rows="3" placeholder="Explain the decision or information requested"><?= h($c['decision_reason']) ?></textarea>
                </label>

                <button class="btn">Save review</button>

                <?php if ($c['status'] === 'Approved'): ?>
                    <a class="mini-btn" href="release.php?claim_id=<?= (int)$c['id'] ?>">
                        Record item release
                    </a>
                <?php endif; ?>
            </form>
            <a class="mini-btn" href="../chat.php?item_id=<?= (int)$c['item_report_id'] ?>&amp;claim_id=<?= (int)$c['id'] ?>">
                Open conversation
            </a>
        </article>
    <?php endforeach; ?>

    <?php if (!$claims): ?>
        <div class="card empty">No claims submitted yet.</div>
    <?php endif; ?>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>