<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';

require_admin();

$perPage = 50;
$page = max(1, (int)($_GET['page'] ?? 1));
$offset = ($page - 1) * $perPage;

$total = (int)$pdo->query('SELECT COUNT(*) FROM admin_activity_logs')->fetchColumn();

$st = $pdo->prepare("SELECT l.*,u.full_name,COALESCE(i.item_name,i2.item_name) AS item_name,COALESCE(i.id,i2.id) AS item_id FROM admin_activity_logs l JOIN users u ON u.id=l.admin_id LEFT JOIN item_reports i ON l.entity_type='item_report' AND i.id=l.entity_id LEFT JOIN claims c ON l.entity_type='claim' AND c.id=l.entity_id LEFT JOIN item_reports i2 ON i2.id=c.item_report_id ORDER BY l.id DESC LIMIT :lim OFFSET :off");

$st->bindValue(':lim', $perPage, PDO::PARAM_INT);
$st->bindValue(':off', $offset, PDO::PARAM_INT);
$st->execute();

$logs = $st->fetchAll();
$pages = max(1, (int)ceil($total / $perPage));

$page_title = 'Activity logs';

require __DIR__ . '/../includes/header.php';
?>

<section class="page-heading">
    <span class="eyebrow">ADMIN</span>
    <h1>Activity logs</h1>
    <p>Record of important Admin decisions and release actions (<?= $total ?> entries).</p>
</section>

<?php if (!$logs): ?>
    <div class="card empty">No activity recorded yet.</div>
<?php else: ?>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Admin</th>
                    <th>Action</th>
                    <th>Item</th>
                    <th>Details</th>
                </tr>
            </thead>

            <tbody>
                <?php foreach ($logs as $l): ?>
                    <tr>
                        <td><?= h($l['created_at']) ?></td>
                        <td><?= h($l['full_name']) ?></td>
                        <td><?= h($l['action']) ?></td>

                        <td>
                            <?php
                            $code = $l['item_id'] ? 'PLM-' . str_pad((string)$l['item_id'], 5, '0', STR_PAD_LEFT) : '';

                            if ($l['entity_type'] === 'claim') {
                                echo h(($l['item_name'] ? $l['item_name'] . ' (' . $code . ')' : 'Item no longer exists') . ' · Claim #' . $l['entity_id']);
                            } elseif ($l['entity_type'] === 'item_report') {
                                echo h($l['item_name'] ? $l['item_name'] . ' (' . $code . ')' : 'Deleted item (PLM-' . str_pad((string)$l['entity_id'], 5, '0', STR_PAD_LEFT) . ')');
                            } else {
                                echo h(ucfirst(str_replace('_', ' ', $l['entity_type'])) . ' #' . $l['entity_id']);
                            }
                            ?>
                        </td>

                        <td><?= h($l['details'] ?? '') ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <p class="muted small">
        <?php if ($page > 1): ?>
            <a class="text-link" href="?page=<?= $page - 1 ?>">← Newer</a>
            &nbsp;
        <?php endif; ?>

        Page <?= $page ?> of <?= $pages ?>

        <?php if ($page < $pages): ?>
            &nbsp;
            <a class="text-link" href="?page=<?= $page + 1 ?>">Older →</a>
        <?php endif; ?>
    </p>

<?php endif; ?>

<?php require __DIR__ . '/../includes/footer.php'; ?>