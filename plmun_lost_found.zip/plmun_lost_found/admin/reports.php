<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';

verify_csrf();
require_admin();

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $action = $_POST['action'] ?? '';

    $s = $pdo->prepare('SELECT * FROM item_reports WHERE id=?');
    $s->execute([$id]);
    $item = $s->fetch();

    $code = 'PLM-' . str_pad((string)$id, 5, '0', STR_PAD_LEFT);

    if (!$item) {
        $error = 'Report not found.';
    } elseif ($item['report_status'] === 'Returned') {
        $error = 'Returned items can no longer be changed.';
    } elseif ($item['report_status'] === 'Draft') {
        $error = 'This report is still a draft and has not been submitted.';
    } elseif ($action === 'clarify') {
        $note = trim($_POST['note'] ?? '');

        if ($note === '' || strlen($note) > 4000) {
            $error = 'Write the clarification you need from the reporter (up to 4,000 characters).';
        } else {
            $dup = $pdo->prepare('SELECT 1 FROM chat_messages m JOIN chat_conversations c ON c.id=m.conversation_id WHERE c.item_report_id=? AND m.sender_id=? AND m.message=? AND m.sent_at > NOW() - INTERVAL 60 SECOND LIMIT 1');
            $dup->execute([$id, current_user_id(), $note]);

            if ($dup->fetchColumn()) {
                $error = 'You already sent this message a moment ago.';
            } else {
                $pdo->prepare("UPDATE item_reports SET report_status='Under Review' WHERE id=?")->execute([$id]);

                post_item_message($pdo, $id, current_user_id(), $note);

                notify_user($pdo, (int)$item['reporter_id'], 'Clarification requested', 'Admin needs more information about ' . $item['item_name'] . '. Open your report chat to reply.');

                log_admin_action($pdo, 'Requested report clarification', 'item_report', $id, $item['item_name'] . ' - ' . $note);
            }
        }
    } elseif (in_array($action, ['publish', 'reject'], true)) {
        $status = $action === 'publish' ? 'Published' : 'Rejected';

        $u = $pdo->prepare('UPDATE item_reports SET report_status=? WHERE id=? AND report_status<>?');
        $u->execute([$status, $id, $status]);

        if ($u->rowCount() === 0) {
            $error = 'This report is already ' . $status . '.';
        } else {
            notify_user($pdo, (int)$item['reporter_id'], 'Report status updated', 'Your report for ' . $item['item_name'] . ' is now ' . $status . '.');

            log_admin_action($pdo, 'Updated report status', 'item_report', $id, $item['item_name'] . ' is now ' . $status);
        }
    } elseif ($action === 'delete') {
        $cc = $pdo->prepare('SELECT COUNT(*) FROM claims WHERE item_report_id=?');
        $cc->execute([$id]);

        if ($item['report_status'] !== 'Rejected') {
            $error = 'Only rejected reports can be deleted.';
        } elseif ((int)$cc->fetchColumn() > 0) {
            $error = 'This report has claims, so it cannot be deleted. Keep it as Rejected.';
        } else {
            try {
                $pdo->beginTransaction();

                $sub = 'SELECT id FROM chat_conversations WHERE item_report_id=?';

                $pdo->prepare("DELETE FROM chat_messages WHERE conversation_id IN ($sub)")->execute([$id]);
                $pdo->prepare("DELETE FROM chat_participants WHERE conversation_id IN ($sub)")->execute([$id]);
                $pdo->prepare('DELETE FROM chat_conversations WHERE item_report_id=?')->execute([$id]);
                $pdo->prepare('DELETE FROM item_custody_records WHERE item_report_id=?')->execute([$id]);
                $pdo->prepare('DELETE FROM item_reports WHERE id=?')->execute([$id]);

                log_admin_action($pdo, 'Deleted rejected report', 'item_report', $id, $item['item_name'] . ' (' . $code . ')');

                $pdo->commit();

                if (!empty($item['photo_path'])) {
                    @unlink(__DIR__ . '/../' . $item['photo_path']);
                }

                notify_user($pdo, (int)$item['reporter_id'], 'Report deleted', 'Your rejected report for ' . $item['item_name'] . ' was removed by Admin.');
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }

                $error = 'Could not delete this report. Please try again.';
            }
        }
    } else {
        $error = 'Invalid report action.';
    }

    if (!$error) {
        header('Location: reports.php');
        exit;
    }
}

$items = $pdo->query("SELECT r.*,u.full_name FROM item_reports r JOIN users u ON u.id=r.reporter_id WHERE r.report_status<>'Draft' ORDER BY r.created_at DESC")->fetchAll();

$page_title = 'Manage reports';

require __DIR__ . '/../includes/header.php';
?>

<section class="page-heading">
    <span class="eyebrow">ADMIN</span>
    <h1>Manage item reports</h1>
    <p>Reports are published automatically. Request clarification, take down a listing, or delete a rejected report.</p>
</section>

<?php if ($error): ?>
    <div class="alert error"><?= h($error) ?></div>
<?php endif; ?>

<div class="list-grid">
    <?php foreach ($items as $it): ?>
        <article class="card">
            <div class="row-between">
                <h3><?= h($it['item_name']) ?> · PLM-<?= str_pad((string)$it['id'], 5, '0', STR_PAD_LEFT) ?></h3>
                <span class="pill"><?= h($it['report_status']) ?></span>
            </div>

            <?php if ($it['photo_path']): ?>
                <img class="item-photo" src="/plmun_lost_found/<?= h($it['photo_path']) ?>" alt="Found item photo">
            <?php endif; ?>

            <p><strong>Reporter:</strong> <?= h($it['full_name']) ?></p>

            <p><strong>Category:</strong> <?= h($it['category']) ?> · <strong>Found:</strong> <?= h($it['date_found']) ?> at <?= h($it['location_found']) ?></p>

            <p><strong>Description:</strong> <?= nl2br(h($it['description'])) ?></p>

            <?php if ($it['report_status'] !== 'Returned'): ?>
                <form method="post" class="inline-form">
                    <?= csrf_field() ?>

                    <input type="hidden" name="id" value="<?= (int)$it['id'] ?>">

                    <input name="note" maxlength="4000" placeholder="Message to reporter (needed for Request clarification)">

                    <?php if ($it['report_status'] !== 'Published'): ?>
                        <button name="action" value="publish" class="mini-btn">Publish</button>
                    <?php endif; ?>

                    <button name="action" value="clarify" class="mini-btn">Request clarification</button>

                    <?php if ($it['report_status'] !== 'Rejected'): ?>
                        <button name="action" value="reject" class="mini-btn danger">Reject</button>
                    <?php endif; ?>
                </form>
            <?php endif; ?>

            <div class="action-row" style="margin:10px 0 0">
                <a class="mini-btn" href="../chat.php?item_id=<?= (int)$it['id'] ?>">Chat with reporter</a>

                <?php if ($it['report_status'] === 'Rejected'): ?>
                    <form method="post" data-confirm="Delete this rejected report permanently?">
                        <?= csrf_field() ?>

                        <input type="hidden" name="id" value="<?= (int)$it['id'] ?>">
                        <input type="hidden" name="action" value="delete">

                        <button class="mini-btn danger">Delete report</button>
                    </form>
                <?php endif; ?>
            </div>
        </article>
    <?php endforeach; ?>

    <?php if (!$items): ?>
        <div class="card empty">No reports yet.</div>
    <?php endif; ?>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>