<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';

verify_csrf();
require_admin();

$claimId = (int)($_GET['claim_id'] ?? $_POST['claim_id'] ?? 0);

$s = $pdo->prepare("SELECT c.*,r.item_name,r.id item_id,r.reporter_id,r.custody_status,u.full_name claimant FROM claims c JOIN item_reports r ON r.id=c.item_report_id JOIN users u ON u.id=c.claimant_id WHERE c.id=?");
$s->execute([$claimId]);
$c = $s->fetch();

if (!$c) {
    http_response_code(404);
    exit('Claim not found.');
}

if ($c['status'] !== 'Approved') {
    http_response_code(403);
    exit('Only an approved claim can be released.');
}

$dr = $pdo->prepare('SELECT 1 FROM item_release_records WHERE item_report_id=? LIMIT 1');
$dr->execute([(int)$c['item_id']]);

if ($dr->fetchColumn()) {
    header('Location: releases.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach (['approved', 'physical', 'identity', 'released'] as $k) {
        if (empty($_POST[$k])) {
            $error = 'Complete every release checklist item before confirming.';
        }
    }

    if (!$error) {
        $notes = trim($_POST['notes'] ?? '');

        $pdo->beginTransaction();

        try {
            $s = $pdo->prepare('INSERT INTO item_release_records(item_report_id,claim_id,approved_by,released_to,custody_at_release,release_notes) VALUES(?,?,?,?,?,?)');
            $s->execute([(int)$c['item_id'], $claimId, current_user_id(), (int)$c['claimant_id'], $c['custody_status'], $notes]);

            $pdo->prepare("UPDATE item_reports SET report_status='Returned' WHERE id=?")->execute([$c['item_id']]);

            log_admin_action($pdo, 'Confirmed item release', 'item_report', (int)$c['item_id'], 'Released to ' . $c['claimant']);

            notify_user($pdo, (int)$c['claimant_id'], 'Item release recorded', 'The release of ' . $c['item_name'] . ' has been recorded by Admin.');
            notify_user($pdo, (int)$c['reporter_id'], 'Item returned', 'The item ' . $c['item_name'] . ' has been recorded as returned.');

            $pdo->commit();

            header('Location: releases.php');
            exit;
        } catch (Throwable $e) {
            $pdo->rollBack();
            $error = 'Could not record release. Check the database and try again.';
        }
    }
}

$page_title = 'Confirm item release';

require __DIR__ . '/../includes/header.php';
?>

<div class="narrow">
    <a class="back-link" href="claims.php">← Claims</a>

    <form method="post" class="card form-card">
        <?= csrf_field() ?>

        <h1>Confirm item release</h1>

        <p><strong>Item:</strong> <?= h($c['item_name']) ?> (#<?= (int)$c['item_id'] ?>)</p>
        <p><strong>Approved claimant:</strong> <?= h($c['claimant']) ?></p>
        <p><strong>Custody at release:</strong> <?= h($c['custody_status']) ?></p>

        <?php if ($error): ?>
            <div class="alert error"><?= h($error) ?></div>
        <?php endif; ?>

        <input type="hidden" name="claim_id" value="<?= $claimId ?>">

        <fieldset>
            <legend>Release checklist (all required)</legend>

            <?php foreach (['approved' => 'Claim approved by authorized Admin', 'physical' => 'Physical item received or located', 'identity' => 'Claimant identity checked according to school policy', 'released' => 'Item physically released to approved claimant'] as $k => $v): ?>
                <label class="radio">
                    <input type="checkbox" name="<?= $k ?>" value="1">
                    <?= h($v) ?>
                </label>
            <?php endforeach; ?>
        </fieldset>

        <label>
            Release notes (optional)
            <textarea name="notes" rows="3"></textarea>
        </label>

        <button class="btn full">Confirm item release</button>
    </form>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>