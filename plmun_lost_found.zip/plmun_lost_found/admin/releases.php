<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';

require_admin();

$rows = $pdo->query('SELECT rr.*,r.item_name,u.full_name claimant,a.full_name admin_name FROM item_release_records rr JOIN item_reports r ON r.id=rr.item_report_id JOIN users u ON u.id=rr.released_to JOIN users a ON a.id=rr.approved_by ORDER BY rr.released_at DESC')->fetchAll();

$page_title = 'Release records';

require __DIR__ . '/../includes/header.php';
?>

<section class="page-heading">
    <span class="eyebrow">ADMIN</span>
    <h1>Item release records</h1>
    <p>Completed item handovers recorded by authorized personnel.</p>
</section>

<div class="table-wrap card">
    <table>
        <thead>
            <tr>
                <th>Item</th>
                <th>Released to</th>
                <th>Admin</th>
                <th>Custody</th>
                <th>Date</th>
                <th>Notes</th>
            </tr>
        </thead>

        <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td><?= h($r['item_name']) ?> (#<?= (int)$r['item_report_id'] ?>)</td>
                    <td><?= h($r['claimant']) ?></td>
                    <td><?= h($r['admin_name']) ?></td>
                    <td><?= h($r['custody_at_release']) ?></td>
                    <td><?= h($r['released_at']) ?></td>
                    <td><?= h($r['release_notes']) ?></td>
                </tr>
            <?php endforeach; ?>

            <?php if (!$rows): ?>
                <tr>
                    <td colspan="6">No release records yet.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>