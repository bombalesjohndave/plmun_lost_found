<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';

require_admin();

$reports = (int)$pdo->query("SELECT COUNT(*) FROM item_reports")->fetchColumn();
$claims = (int)$pdo->query("SELECT COUNT(*) FROM claims")->fetchColumn();
$pending = (int)$pdo->query("SELECT COUNT(*) FROM claims WHERE status IN ('Pending Review','Under Verification','Additional Information Required','Unresolved / On Hold')")->fetchColumn();
$returned = (int)$pdo->query("SELECT COUNT(*) FROM item_reports WHERE report_status='Returned'")->fetchColumn();

$page_title = 'Admin Dashboard';

require __DIR__ . '/../includes/header.php';
?>

<section class="page-heading">
    <span class="eyebrow">AUTHORIZED PERSONNEL</span>
    <h1>Admin dashboard</h1>
    <p>Review reports, assess ownership claims, and maintain release records.</p>
</section>

<div class="stats-grid">
    <div class="stat card">
        <strong><?= $reports ?></strong>
        <span>Total reports</span>
    </div>

    <div class="stat card">
        <strong><?= $claims ?></strong>
        <span>Total claims</span>
    </div>

    <div class="stat card">
        <strong><?= $pending ?></strong>
        <span>Claims to review</span>
    </div>

    <div class="stat card">
        <strong><?= $returned ?></strong>
        <span>Returned items</span>
    </div>
</div>

<div class="choice-grid admin-links">
    <a class="choice-card" href="reports.php">
        <h2>Manage item reports</h2>
        <p>Monitor posted reports and take down listings that need action.</p>
        <span class="text-link">Open reports</span>
    </a>

    <a class="choice-card" href="claims.php">
        <h2>Review ownership claims</h2>
        <p>Assess claim information and update claim decisions.</p>
        <span class="text-link">Review claims</span>
    </a>

    <a class="choice-card" href="releases.php">
        <h2>Item release records</h2>
        <p>Review completed handovers and release history.</p>
        <span class="text-link">Open release records</span>
    </a>

    <a class="choice-card" href="logs.php">
        <h2>Activity logs</h2>
        <p>See Admin decisions, claim reviews, and release actions.</p>
        <span class="text-link">View logs</span>
    </a>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>