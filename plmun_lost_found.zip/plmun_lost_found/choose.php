
<?php

require_once __DIR__ . '/includes/auth.php';

require_login();

if (($_SESSION['role'] ?? '') === 'admin') {
    header('Location: admin/dashboard.php');
    exit;
}

$q = trim($_GET['q'] ?? '');
$cat = trim($_GET['category'] ?? '');

$cats = [
    'Electronics',
    'Bags',
    'Accessories',
    'School Supplies',
    'Clothing',
    'Personal Belongings',
    'Others'
];

$sql = "SELECT id, item_name, category, location_found, date_found, photo_path
        FROM item_reports
        WHERE report_status = 'Published'";

$args = [];

if ($q !== '') {
    $sql .= ' AND (
        item_name LIKE ?
        OR category LIKE ?
        OR location_found LIKE ?
        OR description LIKE ?
    )';

    array_push($args, "%$q%", "%$q%", "%$q%", "%$q%");
}

if (in_array($cat, $cats, true)) {
    $sql .= ' AND category = ?';
    $args[] = $cat;
}

$sql .= ' ORDER BY created_at DESC, id DESC LIMIT 60';

$stmt = $pdo->prepare($sql);
$stmt->execute($args);

$items = $stmt->fetchAll();

$page_title = 'Browse items';

require __DIR__ . '/includes/header.php';
?>
<section class="page-heading">
    <span class="eyebrow">
        WELCOME, <?= h(strtoupper($_SESSION['name'] ?? 'USER')) ?>
    </span>
    <h1>Find your lost item</h1>
    <p>
        Search items reported by the PLMun community.
        Found something instead?
    </p>
     <a class="mobile-only" href="reporter/report.php">
        Report a found item
    </a>
</section>
<form class="searchbar" method="get">
    <input
        name="q"
        value="<?= h($q) ?>"
        placeholder="Search by item, category, or location"
    >
    <select name="category">
        <option value="">All categories</option>
        <?php foreach ($cats as $c): ?>
            <option <?= $cat === $c ? 'selected' : '' ?>>
                <?= h($c) ?>
            </option>
        <?php endforeach; ?>
    </select>
    <button class="btn">Search</button>
</form>
<?php if (!$items): ?>
    <div class="empty card">
        <h3>No items found</h3>
        <p>
            Try another keyword or category,
            or check again later.
        </p>
    </div>
<?php else: ?>
    <div class="list-grid">
        <?php foreach ($items as $item): ?>
            <a
                class="item-card clickable"
                href="claimant/item.php?id=<?= (int)$item['id'] ?>"
            >
                <?php if (!empty($item['photo_path'])): ?>
                    <img
                        class="item-photo"
                        src="/plmun_lost_found/<?= h($item['photo_path']) ?>"
                        alt="Found item photo"
                    >
                <?php else: ?>
                    <div class="item-placeholder">◇</div>
                <?php endif; ?>
                <div class="item-info">
                    <h3><?= h($item['item_name']) ?></h3>
                    <p>
                        <?= h($item['category']) ?>
                        ·
                        <?= h($item['location_found']) ?>
                    </p>
                    <small>
                        Found: <?= h($item['date_found']) ?>
                    </small>
                    <span class="text-link">
                        View details 
                    </span>
                </div>
            </a>
        <?php endforeach; ?>

    </div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>
