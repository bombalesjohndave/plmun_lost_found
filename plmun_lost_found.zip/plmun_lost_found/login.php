
<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';

verify_csrf();
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    $stmt = $pdo->prepare(
        'SELECT id, full_name, password_hash, role
         FROM users
         WHERE school_email = ? AND is_active = 1'
    );
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    if ($user && password_verify($password, $user['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['user_id'] = (int)$user['id'];
        $_SESSION['name'] = $user['full_name'];
        $_SESSION['role'] = $user['role'];
        header(
            'Location: ' .
            ($user['role'] === 'admin'
                ? 'admin/dashboard.php'
                : 'choose.php')
        );
        exit;
    }
    $error = 'Invalid email or password.';
}
$page_title = 'Log in';
require __DIR__ . '/includes/header.php';
?>
<div class="auth-wrap">
    <form class="card form-card" method="post">
        <?= csrf_field() ?>
        <img
            class="seal-placeholder"
            src="https://imgs.search.brave.com/l0wB8jD9hv2ZXxKCgkJOLK_rhtRIkCf_KI0ljuXCmOA/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly91cGxv/YWQud2lraW1lZGlh/Lm9yZy93aWtpcGVk/aWEvZW4vYi9iMS9Q/YW1hbnRhc2FuX25n/X0x1bmdzb2Rfbmdf/TXVudGlubHVwYV9s/b2dvLnBuZz91dG1f/c291cmNlPWVuLndp/a2lwZWRpYS5vcmcm/YW1wO3V0bV9jYW1w/YWlnbj1pbmRleCZh/bXA7dXRtX2NvbnRl/bnQ9dGh1bWJuYWls/X3Vuc2NhbGVk"
            alt=""
        >
        <h1>PLMun Lost and Found</h1>  
        <?php if (isset($_GET['registered'])): ?>
            <div class="alert success">
                Account created. You can now log in.
            </div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert error">
                <?= h($error) ?>
            </div>
        <?php endif; ?>
        <label>
            School email
            <input
                type="email"
                name="email"
                required
                autocomplete="username"
                placeholder="e.g. fullname_program@plmun.edu.ph"
            >
        </label>
        <label>
            Password
            <span class="password-field">
                <input
                type="password"
                name="password"
                required
                autocomplete="current-password"
                placeholder="Your Password"
            >
            <button type="button" class="toggle-password" aria-label="Show password" aria-pressed="false">Show</button>
            </span>
            
        </label>
        <button class="btn full">
            Log in
        </button>
        <p class="muted center">
            New user?
            <a href="register.php">Create an account</a>
        </p>
    </form>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
