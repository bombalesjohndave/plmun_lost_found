<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';

require_login();

$q = trim($_GET['q'] ?? '');

$sql = "SELECT id,item_name,category,location_found,date_found,photo_path FROM item_reports WHERE report_status='Published'";
$args = [];

if ($q !== '') {
    $sql .= " AND (item_name LIKE ? OR category LIKE ? OR location_found LIKE ?)";
    $args = ["%$q%", "%$q%", "%$q%"];
}

$sql .= " ORDER BY created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($args);
$items = $stmt->fetchAll();

$myStmt = $pdo->prepare('SELECT c.id claim_id,c.item_report_id,c.status,c.created_at,c.decision_reason,r.item_name,r.category,r.location_found,r.date_found,r.photo_path,r.report_status FROM claims c JOIN item_reports r ON r.id=c.item_report_id WHERE c.claimant_id=? ORDER BY c.created_at DESC');
$myStmt->execute([current_user_id()]);
$myClaims = $myStmt->fetchAll();

$page_title = 'Search found items';

require __DIR__ . '/../includes/header.php';
?>

<section class="page-heading">
    <span class="eyebrow">CLAIMANT</span>
    <h1>Find your lost item</h1>
    <p>Search published found-item reports from the PLMun community.</p>
</section>

<section class="section-head">
    <h2>My Claims</h2>
    <span class="pill"><?= count($myClaims) ?> claims</span>
</section>

<?php if ($myClaims): ?>
    <div class="list-grid">
        <?php foreach ($myClaims as $mc): ?>
            <article class="card">
                <?php if (!empty($mc['photo_path'])): ?>
                    <img class="item-photo" src="/plmun_lost_found/<?= h($mc['photo_path']) ?>" alt="Item you claimed">
                <?php else: ?>
                    <div class="item-placeholder">◇</div>
                <?php endif; ?>

                <div class="row-between">
                    <h3><?= h($mc['item_name']) ?></h3>
                    <span class="pill"><?= h($mc['status']) ?></span>
                </div>

                <p><?= h($mc['category']) ?> · <?= h($mc['location_found']) ?> · Found: <?= h($mc['date_found']) ?></p>
                <p class="muted small">Claim #<?= (int)$mc['claim_id'] ?> · submitted <?= h($mc['created_at']) ?></p>

                <?php if ($mc['decision_reason']): ?>
                    <p><strong>Admin note:</strong> <?= h($mc['decision_reason']) ?></p>
                <?php endif; ?>

                <?php if ($mc['report_status'] === 'Published'): ?>
                    <a class="mini-btn" href="item.php?id=<?= (int)$mc['item_report_id'] ?>">View item</a>
                <?php endif; ?>
                <a class="mini-btn" href="../chat.php?item_id=<?= (int)$mc['item_report_id'] ?>&amp;claim_id=<?= (int)$mc['claim_id'] ?>">Chat with Reporter / Admin</a>
            </article>
        <?php endforeach; ?>
    </div>
<?php else: ?>
    <p class="muted small">Your submitted claims will appear here.</p>
<?php endif; ?>

<?php require __DIR__ . '/../includes/footer.php'; ?>