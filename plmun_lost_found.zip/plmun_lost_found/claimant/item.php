<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';

require_login();

$id = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM item_reports WHERE id=? AND report_status='Published'");
$stmt->execute([$id]);
$item = $stmt->fetch();

if (!$item) {
    http_response_code(404);
    exit('Item not found.');
}

$own = (int)$item['reporter_id'] === current_user_id();

$ex = $pdo->prepare('SELECT id FROM claims WHERE item_report_id=? AND claimant_id=?');
$ex->execute([$id, current_user_id()]);
$existing = (int)$ex->fetchColumn();

$page_title = 'Item details';

require __DIR__ . '/../includes/header.php';
?>

<div class="narrow">
    <a class="back-link" href="/plmun_lost_found/choose.php">← Search items</a>

    <article class="card detail-card">
        <?php if (!empty($item['photo_path'])): ?>
            <img class="detail-photo" src="/plmun_lost_found/<?= h($item['photo_path']) ?>" alt="Found item photo">
        <?php else: ?>
            <div class="detail-image">◇</div>
        <?php endif; ?>

        <span class="status">Published listing</span>

        <h1><?= h($item['item_name']) ?></h1>
        <p><?= h($item['category']) ?></p>

        <dl>
            <dt>Location found</dt>
            <dd><?= h($item['location_found']) ?></dd>

            <dt>Date found</dt>
            <dd><?= h($item['date_found']) ?></dd>

            <dt>Item ID</dt>
            <dd>PLM-<?= str_pad((string)$item['id'], 5, '0', STR_PAD_LEFT) ?></dd>
        </dl>

        <p class="muted">Some identifying details may be withheld to help protect the ownership verification process.</p>

        <?php if ($own): ?>
            <div class="alert error">You reported this item, so you cannot claim it.</div>
        <?php elseif ($existing): ?>
            <a class="btn full" href="../chat.php?item_id=<?= (int)$item['id'] ?>&amp;claim_id=<?= $existing ?>">
                You already submitted a claim. Open conversation
            </a>
        <?php else: ?>
            <a class="btn full" href="claim.php?item_id=<?= (int)$item['id'] ?>">
                Is this your lost item? Submit a claim
            </a>
        <?php endif; ?>
    </article>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>