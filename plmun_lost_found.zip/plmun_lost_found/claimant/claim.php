<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';

verify_csrf();
require_login();

$item_id = (int)($_GET['item_id'] ?? $_POST['item_id'] ?? 0);

$stmt = $pdo->prepare("SELECT id,item_name,reporter_id FROM item_reports WHERE id=? AND report_status='Published'");
$stmt->execute([$item_id]);
$item = $stmt->fetch();

if (!$item) {
    http_response_code(404);
    exit('Item not found.');
}

if ((int)$item['reporter_id'] === current_user_id()) {
    http_response_code(403);
    exit('You cannot claim an item that you reported.');
}

$dup = $pdo->prepare('SELECT id FROM claims WHERE item_report_id=? AND claimant_id=?');
$dup->execute([$item_id, current_user_id()]);
$existingClaim = (int)$dup->fetchColumn();

$error = '';
$ok = false;
$newClaimId = 0;
$uploadedEvidencePath = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $where = trim($_POST['last_seen_location'] ?? '');
    $when = trim($_POST['last_seen_time'] ?? '');
    $details = trim($_POST['remembered_details'] ?? '');

    if ($where === '' || $when === '' || $details === '') {
        $error = 'Please answer all required questions.';
    } elseif (strlen($where) > 5000 || strlen($when) > 500 || strlen($details) > 5000) {
        $error = 'One of your answers is too long.';
    } elseif ($existingClaim) {
        $error = 'You already submitted a claim for this item.';
    } else {
        $pdo->beginTransaction();

        try {
            $stmt = $pdo->prepare("INSERT INTO claims(item_report_id,claimant_id,last_seen_location,last_seen_time,remembered_details,status) VALUES(?,?,?,?,?,'Pending Review')");
            $stmt->execute([$item_id, current_user_id(), $where, $when, $details]);

            $newClaimId = (int)$pdo->lastInsertId();

            if (isset($_FILES['evidence']) && $_FILES['evidence']['error'] !== UPLOAD_ERR_NO_FILE) {
                $file = $_FILES['evidence'];

                if ($file['error'] !== UPLOAD_ERR_OK) {
                    throw new RuntimeException('Evidence upload failed.');
                }

                if ($file['size'] > 8 * 1024 * 1024) {
                    throw new RuntimeException('Evidence must be 8 MB or smaller.');
                }

                $finfo = new finfo(FILEINFO_MIME_TYPE);
                $mime = $finfo->file($file['tmp_name']);

                $types = [
                    'image/jpeg' => 'jpg',
                    'image/png' => 'png',
                    'image/webp' => 'webp',
                    'application/pdf' => 'pdf'
                ];

                if (!isset($types[$mime])) {
                    throw new RuntimeException('Evidence must be JPG, PNG, WEBP, or PDF.');
                }

                $dir = __DIR__ . '/../uploads/evidence';

                if (!is_dir($dir)) {
                    mkdir($dir, 0750, true);
                }

                $stored = bin2hex(random_bytes(20)) . '.' . $types[$mime];

                if (!move_uploaded_file($file['tmp_name'], $dir . '/' . $stored)) {
                    throw new RuntimeException('Could not securely save evidence.');
                }

                $uploadedEvidencePath = $dir . '/' . $stored;

                $ins = $pdo->prepare('INSERT INTO claim_evidence(claim_id,uploaded_by,original_name,stored_name,mime_type,file_size) VALUES(?,?,?,?,?,?)');
                $ins->execute([$newClaimId, current_user_id(), basename($file['name']), $stored, $mime, (int)$file['size']]);
            }

            notify_admins($pdo, 'New ownership claim', 'A new claim was submitted for item #' . $item_id . '.');

            notify_user($pdo, (int)$item['reporter_id'], 'New ownership claim', 'A claim was submitted for your found-item report #' . $item_id . '.');

            $pdo->commit();

            $ok = true;
        } catch (Throwable $e) {
            $pdo->rollBack();

            if ($uploadedEvidencePath && is_file($uploadedEvidencePath)) {
                @unlink($uploadedEvidencePath);
            }

            $error = $e instanceof RuntimeException ? $e->getMessage() : 'Unable to submit the claim. Please try again.';
        }
    }
}

$page_title = 'Submit ownership claim';

require __DIR__ . '/../includes/header.php';
?>

<div class="narrow">
    <a class="back-link" href="item.php?id=<?= $item_id ?>">← Item details</a>

    <form class="card form-card" method="post" enctype="multipart/form-data">
        <?= csrf_field() ?>

        <input type="hidden" name="item_id" value="<?= $item_id ?>">

        <h1>Submit ownership claim</h1>

        <p class="muted">
            Possible item: <strong><?= h($item['item_name']) ?></strong>
        </p>

        <?php if ($error): ?>
            <div class="alert error"><?= h($error) ?></div>
        <?php endif; ?>

        <?php if ($ok): ?>
            <div class="alert success">
                Your claim and any evidence were submitted for Admin review.
                <a href="../chat.php?item_id=<?= $item_id ?>&amp;claim_id=<?= $newClaimId ?>">Open claim conversation</a>.
            </div>
        <?php endif; ?>

        <label>
            Where did you last see or use the item?
            <textarea name="last_seen_location" required rows="2"></textarea>
        </label>

        <label>
            When did you last see or use it?
            <input name="last_seen_time" required maxlength="500" placeholder="Approximate date and time">
        </label>

        <label>
            What additional details do you remember?
            <textarea name="remembered_details" required rows="3"></textarea>
        </label>

        <label>
            Supporting evidence
            <span class="muted">(optional; JPG, PNG, WEBP, or PDF; max 8 MB)</span>
            <input type="file" name="evidence" accept="image/jpeg,image/png,image/webp,application/pdf">
        </label>

        <p class="muted small">
            Evidence is private and available only to the claimant and authorized Admin personnel. It is not mandatory proof.
        </p>

        <button class="btn full">Submit claim</button>
    </form>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>