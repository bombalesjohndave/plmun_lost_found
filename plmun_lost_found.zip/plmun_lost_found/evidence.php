
<?php

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';

require_login();

$id = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare(
    'SELECT e.*, c.claimant_id, r.reporter_id
     FROM claim_evidence e
     JOIN claims c ON c.id = e.claim_id
     JOIN item_reports r ON r.id = c.item_report_id
     WHERE e.id = ?'
);

$stmt->execute([$id]);

$e = $stmt->fetch();

if (!$e) {
    http_response_code(404);
    exit('Evidence not found.');
}

$uid = current_user_id();
$admin = ($_SESSION['role'] ?? '') === 'admin';

if (!$admin && (int)$e['claimant_id'] !== $uid) {
    http_response_code(403);
    exit('Access denied.');
}

$path = __DIR__ . '/uploads/evidence/' . $e['stored_name'];

if (!is_file($path)) {
    http_response_code(404);
    exit('File unavailable.');
}

header('X-Content-Type-Options: nosniff');
header('Content-Type: ' . $e['mime_type']);
$inline = isset($_GET['inline']) && in_array($e['mime_type'], ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'], true);
header('Content-Disposition: ' . ($inline ? 'inline' : 'attachment') . '; filename="' . rawurlencode($e['original_name']) . '"');
header('Content-Length: ' . filesize($path));

readfile($path);

exit;
