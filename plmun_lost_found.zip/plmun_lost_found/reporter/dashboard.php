<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';

require_login();
verify_csrf();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_draft'])) {
    $did = (int)($_POST['id'] ?? 0);

    $du = $pdo->prepare("UPDATE item_reports SET report_status='Published' WHERE id=? AND reporter_id=? AND report_status='Draft'");
    $du->execute([$did, current_user_id()]);

    if ($du->rowCount()) {
        notify_user($pdo, current_user_id(), 'Report published', 'Your draft (Item #' . $did . ') is now published and searchable.');
        notify_admins($pdo, 'New found-item report', 'A new report was posted: Item #' . $did . '.');
    }

    header('Location: dashboard.php');
    exit;
}

$filters = ['Draft', 'Under Review', 'Published', 'Returned', 'Rejected'];
$sf = $_GET['s'] ?? 'All';

if (!in_array($sf, $filters, true)) {
    $sf = 'All';
}

$sql = "SELECT id,item_name,category,date_found,report_status,custody_status,photo_path FROM item_reports WHERE reporter_id=?";
$args = [current_user_id()];

if ($sf !== 'All') {
    $sql .= ' AND report_status=?';
    $args[] = $sf;
}

$sql .= ' ORDER BY created_at DESC';

$stmt = $pdo->prepare($sql);
$stmt->execute($args);
$items = $stmt->fetchAll();

$cq = $pdo->prepare('SELECT report_status, COUNT(*) FROM item_reports WHERE reporter_id=? GROUP BY report_status');
$cq->execute([current_user_id()]);
$counts = $cq->fetchAll(PDO::FETCH_KEY_PAIR);

$totalAll = (int)array_sum($counts);

$page_title = 'Reporter Dashboard';

require __DIR__ . '/../includes/header.php';
?>

<section class="page-heading">
    <span class="eyebrow">REPORTER</span>
    <h1>My found-item reports</h1>
    <p>Submit a found item or check the status of your reports.</p>
</section>

<div class="section-head">
    <h2>My Reports</h2>
    <span class="pill"><?= count($items) ?> reports</span>
</div>

<div style="display:flex;flex-wrap:wrap;gap:8px;margin:0 0 18px">
    <?php foreach (array_merge(['All'], $filters) as $f): 
        $cnt = $f === 'All' ? $totalAll : (int)($counts[$f] ?? 0);
    ?>
        <a class="mini-btn"
            href="?s=<?= urlencode($f) ?>"
            style="display:inline-block;text-decoration:none;<?= $sf === $f ? 'background:var(--green);color:#fff;' : '' ?>">
            <?= h($f) ?> <?= $cnt ?>
        </a>
    <?php endforeach; ?>
</div>

<?php if (!$items): ?>
    <div class="empty card">
        <div class="empty-icon"></div>
        <h3><?= $sf === 'All' ? 'No reports yet' : 'No ' . h($sf) . ' reports' ?></h3>
        <p>When you find an item on campus, submit a report here.</p>
    </div>
<?php else: ?>
    <div class="list-grid">
        <?php foreach ($items as $item): ?>
            <article class="item-card">
                <?php if ($item['photo_path']): ?>
                    <img class="item-photo" src="/plmun_lost_found/<?= h($item['photo_path']) ?>" alt="Found item photo">
                <?php else: ?>
                    <div class="item-placeholder">◇</div>
                <?php endif; ?>

                <div class="item-info">
                    <h3><?= h($item['item_name']) ?></h3>

                    <p><?= h($item['category']) ?> · <?= h($item['date_found']) ?></p>

                    <span class="status"><?= h($item['report_status']) ?></span>

                    <small>Custody: <?= h($item['custody_status']) ?></small>

                    <?php if ($item['report_status'] === 'Draft'): ?>
                        <form method="post">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= (int)$item['id'] ?>">
                            <button class="mini-btn" name="submit_draft" value="1">Publish draft</button>
                        </form>
                    <?php endif; ?>

                    <a class="text-link" href="../chat.php?item_id=<?= (int)$item['id'] ?>">
                        Chat with Admin 
                    </a>

                    <?php
                    $cs = $pdo->prepare('SELECT id FROM claims WHERE item_report_id=? ORDER BY created_at DESC');
                    $cs->execute([(int)$item['id']]);

                    foreach ($cs->fetchAll(PDO::FETCH_COLUMN) as $cid):
                    ?>
                        <a class="text-link" href="../chat.php?item_id=<?= (int)$item['id'] ?>&amp;claim_id=<?= (int)$cid ?>">
                            Chat with Claimant
                        </a>
                    <?php endforeach; ?>
                </div>
            </article>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php require __DIR__ . '/../includes/footer.php'; ?>