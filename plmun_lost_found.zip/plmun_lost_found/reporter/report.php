<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';

verify_csrf();
require_login();

$error = '';
$asDraft = false;
$ok = false;
$newId = 0;

$old = fn(string $k, string $d = ''): string => h((string)($_POST[$k] ?? $d));

$done = (int)($_GET['done'] ?? 0);

if ($done > 0) {
    $ds = $pdo->prepare('SELECT report_status FROM item_reports WHERE id=? AND reporter_id=?');
    $ds->execute([$done, current_user_id()]);
    $dst = $ds->fetchColumn();

    if ($dst !== false) {
        $ok = true;
        $newId = $done;
        $asDraft = ($dst === 'Draft');
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $asDraft = isset($_POST['save_draft']);

    $name = trim($_POST['item_name'] ?? '');
    $cat = trim($_POST['category'] ?? '');
    $desc = trim($_POST['description'] ?? '');
    $loc = trim($_POST['location_found'] ?? '');
    $date = $_POST['date_found'] ?? '';
    $custody = $_POST['custody_status'] ?? 'Admin';
    $photoPath = null;

    if ($name === '' || $cat === '' || $desc === '' || $loc === '' || $date === '') {
        $error = 'Please complete all required fields.';
    } elseif (!($dt = DateTime::createFromFormat('Y-m-d', $date)) || $dt->format('Y-m-d') !== $date) {
        $error = 'Please enter a valid date.';
    } elseif ($date > date('Y-m-d')) {
        $error = 'Date found cannot be in the future.';
    } elseif (!in_array($custody, ['Admin', 'Reporter'], true)) {
        $error = 'Please choose a valid custody option.';
    } elseif (!empty($_FILES['item_photo']['name'])) {
        if ($_FILES['item_photo']['error'] !== UPLOAD_ERR_OK) {
            $error = 'The photo could not be uploaded. Please try again.';
        } elseif ($_FILES['item_photo']['size'] > 5 * 1024 * 1024) {
            $error = 'Photo must be 5 MB or smaller.';
        } else {
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime = $finfo->file($_FILES['item_photo']['tmp_name']);
            $exts = [
                'image/jpeg' => 'jpg',
                'image/png' => 'png',
                'image/webp' => 'webp'
            ];

            if (!isset($exts[$mime])) {
                $error = 'Upload a JPG, PNG, or WEBP image.';
            } else {
                $dir = __DIR__ . '/../uploads/items';

                if (!is_dir($dir)) {
                    mkdir($dir, 0755, true);
                }

                $filename = bin2hex(random_bytes(16)) . '.' . $exts[$mime];

                if (move_uploaded_file($_FILES['item_photo']['tmp_name'], $dir . '/' . $filename)) {
                    $photoPath = 'uploads/items/' . $filename;
                } else {
                    $error = 'Unable to save the uploaded photo.';
                }
            }
        }
    }

    if (!$error) {
        $stmt = $pdo->prepare("INSERT INTO item_reports (reporter_id,item_name,category,description,location_found,date_found,custody_status,report_status,photo_path) VALUES (?,?,?,?,?,?,?,?,?)");
        $stmt->execute([
            current_user_id(),
            $name,
            $cat,
            $desc,
            $loc,
            $date,
            $custody,
            $asDraft ? 'Draft' : 'Published',
            $photoPath
        ]);

        $newId = (int)$pdo->lastInsertId();

        $cust = $pdo->prepare('INSERT INTO item_custody_records(item_report_id,from_custodian,to_custodian,recorded_by,notes) VALUES(?,NULL,?,?,?)');
        $cust->execute([
            $newId,
            $custody,
            current_user_id(),
            'Initial custody selected when report was submitted.'
        ]);

        if (!$asDraft) {
            notify_user($pdo, current_user_id(), 'Report published', 'Your report for ' . $name . ' (Item #' . $newId . ') is now published and searchable.');
            notify_admins($pdo, 'New found-item report', 'A new report was posted: ' . $name . ' (Item #' . $newId . ').');
        }

        header('Location: report.php?done=' . $newId);
        exit;
    }
}

$page_title = 'Report found item';

require __DIR__ . '/../includes/header.php';
?>

<div class="narrow">
    <a class="back-link" href="dashboard.php">← My reports</a>

    <form class="card form-card" method="post" enctype="multipart/form-data" data-autosave="report-found">
        <?= csrf_field() ?>

        <h1>Report a found item</h1>

        <p class="muted">Provide accurate details so the owner can recognize it. Your answers are kept if you refresh the page.</p>

        <?php if ($error): ?>
            <div class="alert error"><?= h($error) ?></div>
        <?php endif; ?>

        <?php if ($ok): ?>
            <div class="alert success" data-clear-autosave>
                <?= $asDraft ? 'Your draft was saved. Publish it from My Reports when you are ready.' : 'Your report is now published and searchable.' ?>
                <a href="../chat.php?item_id=<?= $newId ?>">Message Admin about this item</a>.
            </div>
        <?php endif; ?>

        <label>
            Item photo
            <span class="muted">(optional, JPG/PNG/WEBP, max 5 MB)</span>
            <input type="file" name="item_photo" accept="image/jpeg,image/png,image/webp">
        </label>

        <label>
            Item name
            <input name="item_name" required placeholder="e.g. Black umbrella" value="<?= $old('item_name') ?>">
        </label>

        <label>
            Category
            <select name="category" required>
                <option value="">Select category</option>
                <?php foreach (['Electronics', 'Bags', 'Accessories', 'School Supplies', 'Clothing', 'Personal Belongings', 'Others'] as $c): ?>
                    <option <?= ($_POST['category'] ?? '') === $c ? 'selected' : '' ?>>
                        <?= h($c) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </label>

        <label>
            Description
            <textarea name="description" required rows="3" placeholder="Describe the item"><?= $old('description') ?></textarea>
        </label>

        <label>
            Location found
            <input name="location_found" required placeholder="e.g. Library" value="<?= $old('location_found') ?>">
        </label>

        <label>
            Date found
            <input type="date" name="date_found" required max="<?= date('Y-m-d') ?>" value="<?= $old('date_found', date('Y-m-d')) ?>">
        </label>

        <fieldset>
            <legend>Where is the item currently located?</legend>

            <label class="radio">
                <input type="radio" name="custody_status" value="Admin" <?= ($_POST['custody_status'] ?? 'Admin') === 'Admin' ? 'checked' : '' ?>>
                Turn over to Admin
            </label>

            <label class="radio">
                <input type="radio" name="custody_status" value="Reporter" <?= ($_POST['custody_status'] ?? '') === 'Reporter' ? 'checked' : '' ?>>
                Keep it temporarily (subject to school policy)
            </label>
        </fieldset>

        <button class="btn full">Submit report</button>

        <button class="btn btn-outline full" name="save_draft" value="1">
            Save as draft
        </button>
    </form>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>