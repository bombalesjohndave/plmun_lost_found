
<?php

require_once __DIR__ . '/includes/auth.php';

if (!empty($_SESSION['user_id'])) {
    header('Location: choose.php');
    exit;
}

$page_title = 'Welcome';
require __DIR__ . '/includes/header.php';

?>
<section class="hero">
    <div class="hero-copy">
        <span class="eyebrow">
            PAMANTASAN NG LUNGSOD NG MUNTINLUPA
        </span>
        <h1>
            Lost something? <em>Found something?</em>
        </h1>
        <p>
            A centralized place for reporting found belongings,
            searching for lost items, and coordinating ownership
            verification at PLMun.
        </p>
        <div class="actions">
            <a class="btn" href="login.php">Log in</a>
            <a class="btn btn-outline" href="register.php">
                Create account
            </a>
        </div>
    </div>
    <div class="hero-card">
        <div class="hero-icon">⌕</div>
        <h2>Find. Report. Reclaim.</h2>
        <p>
            Every report and claim is reviewed through a
            staff-assisted process before an item is released.
        </p>
    </div>
</section>
<section class="feature-grid">
    <article class="card">
        <div class="icon">＋</div>
        <h3>Report found items</h3>
        <p>
            Submit item details, where it was found,
            and its current custody.
        </p>
    </article>
    <article class="card">
        <div class="icon">⌕</div>
        <h3>Search listings</h3>
        <p>
            Browse published reports and filter by
            keyword or category.
        </p>
    </article>
    <article class="card">
        <div class="icon">✓</div>
        <h3>Verify ownership</h3>
        <p>
            Submit an item claim for review by
            authorized school personnel.
        </p>
    </article>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
