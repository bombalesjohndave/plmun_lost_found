<?php
require_once __DIR__ . '/auth.php';

$page_title = $page_title ?? 'PLMun Lost & Found';
$script_name = $_SERVER['SCRIPT_NAME'] ?? '';
$logged_in = !empty($_SESSION['user_id']);
$is_admin = ($_SESSION['role'] ?? '') === 'admin';
$unread = 0;
$recent_notifs = [];

if ($logged_in) {
  $nq = $pdo->prepare('SELECT COUNT(*) FROM notifications WHERE user_id=? AND is_read=0');
  $nq->execute([current_user_id()]);
  $unread = (int)$nq->fetchColumn();
  $rq = $pdo->prepare('SELECT title,body,is_read,created_at FROM notifications WHERE user_id=? ORDER BY created_at DESC, id DESC LIMIT 8');
  $rq->execute([current_user_id()]);
  $recent_notifs = $rq->fetchAll();
}

$nav_links = $is_admin
  ? [
    ['admin/dashboard.php', 'Dashboard'],
    ['admin/reports.php', 'Manage reports'],
    ['admin/claims.php', 'Review claims'],
    ['admin/releases.php', 'Release records'],
    ['admin/logs.php', 'Activity logs']
  ]
  : [
    ['choose.php', 'Browse items'],
    ['reporter/report.php', 'Report a found item'],
    ['reporter/dashboard.php', 'My reports'],
    ['claimant/dashboard.php', 'My claims']
  ];
?>

<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= h($page_title) ?> | PLMun Lost & Found</title>
  <link rel="stylesheet" href="<?= h(asset('assets/css/style.css')) ?>">
</head>

<body class="<?= $logged_in ? 'has-side' : '' ?>">
  <header class="topbar">
    <div class="topbar-left">
      <?php if ($logged_in): ?>
        <button class="menu-toggle" type="button" id="menuToggle" aria-label="Open menu" aria-expanded="false" aria-controls="sidenav">&#9776;</button>
      <?php endif; ?>
      <a class="brand" href="/plmun_lost_found/">
        <img
          class="brand-mark"
          src="<?= h(asset('assets/images/plmun.png')) ?>"
          alt="PLMun Logo">
        <span>
          <strong>PLMun</strong>
          <small>Lost &amp; Found</small>
        </span>
      </a>
    </div>

    <div class="topbar-right">
      <?php if ($logged_in): ?>
        <div class="notif-wrap">
          <button class="nav-bell" type="button" id="bellBtn" aria-label="Notifications" aria-expanded="false" aria-controls="notifPanel">
            <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" viewBox="0 0 16 16">
              <path d="M8 16a2 2 0 0 0 2-2H6a2 2 0 0 0 2 2M8 1.918l-.797.161A4 4 0 0 0 4 6c0 .628-.134 2.197-.459 3.742-.16.767-.376 1.566-.663 2.258h10.244c-.287-.692-.502-1.49-.663-2.258C12.134 8.197 12 6.628 12 6a4 4 0 0 0-3.203-3.92zM14.22 12c.223.447.481.801.78 1H1c.299-.199.557-.553.78-1C2.68 10.2 3 6.88 3 6c0-2.42 1.72-4.44 4.005-4.901a1 1 0 1 1 1.99 0A5 5 0 0 1 13 6c0 .88.32 4.2 1.22 6" />
            </svg><?php if ($unread): ?><span class="nav-badge"><?= $unread ?></span><?php endif; ?>
          </button>
          <div class="notif-panel" id="notifPanel" hidden>
            <div class="notif-head">
              <strong>Notifications</strong>
              <?php if ($unread): ?>
                <form method="post" action="/plmun_lost_found/notifications.php"><?= csrf_field() ?><input type="hidden" name="action" value="mark_all"><input type="hidden" name="back" value="<?= h($_SERVER['REQUEST_URI'] ?? '') ?>"><button class="notif-link" type="submit">Mark all as read</button></form>
              <?php endif; ?>
              <form method="post" action="/plmun_lost_found/notifications.php"
                data-confirm="Delete ALL notifications? This cannot be undone.">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="delete_all">
                <input type="hidden" name="back" value="<?= h($_SERVER['REQUEST_URI'] ?? '') ?>">
                <button class="notif-link danger" type="submit">Delete all</button>
              </form>
            </div>
            <div class="notif-list">
              <?php foreach ($recent_notifs as $n): ?>
                <div class="notif-item <?= $n['is_read'] ? '' : 'unread' ?>">
                  <strong><?= h($n['title']) ?></strong>
                  <span><?= h($n['body']) ?></span>
                  <small><?= h($n['created_at']) ?></small>
                </div>
              <?php endforeach; ?>
              <?php if (!$recent_notifs): ?><div class="notif-empty">No notifications yet.</div><?php endif; ?>
            </div>
            <div class="notif-foot"><a href="/plmun_lost_found/notifications.php">View all notifications</a></div>
          </div>
        </div>
      <?php else: ?>

        <?php
        $is_auth_page = in_array(basename($script_name), [
          'login.php',
          'register.php'
        ]);
        ?>

        <?php if (!$is_auth_page): ?>
          <nav class="desktop-nav">
            <a href="/plmun_lost_found/login.php">Log in</a>
            <a class="nav-cta" href="/plmun_lost_found/register.php">
              Create account
            </a>
          </nav>
        <?php endif; ?>

      <?php endif; ?>
    </div>
  </header>

  <?php if ($logged_in): ?>
    <div class="nav-overlay" id="navOverlay" hidden></div>
    <aside class="side-nav" id="sidenav" aria-hidden="true">
      <a class="brand side-brand" href="/plmun_lost_found/">
        <img
          class="brand-mark"
          src="<?= h(asset('assets/images/plmun.png')) ?>"
          alt="PLMun Logo">

        <span>
          <strong>PLMun</strong>
          <small>Lost &amp; Found</small>
        </span>
      </a>

      <div class="side-user">
        <strong><?= h($_SESSION['name'] ?? 'User') ?></strong>
        <small><?= $is_admin ? 'Administrator' : 'PLMun community' ?></small>
      </div>

      <?php foreach ($nav_links as $l): ?>
        <a class="<?= $script_name === '/plmun_lost_found/' . $l[0] ? 'active' : '' ?>"
          href="/plmun_lost_found/<?= h($l[0]) ?>">
          <?= h($l[1]) ?>
        </a>
      <?php endforeach; ?>

      <!-- <a class="<?= $script_name === '/plmun_lost_found/notifications.php' ? 'active' : '' ?>"
        href="/plmun_lost_found/notifications.php">
        Notifications<?php if ($unread): ?><span class="nav-badge"><?= $unread ?></span><?php endif; ?>
      </a> -->

      <form method="post" action="/plmun_lost_found/logout.php" class="nav-logout">
        <?= csrf_field() ?>
        <button type="submit" class="nav-link btn-outline-danger">Log out</button>
      </form>
    </aside>
  <?php endif; ?>

  <main class="container">