</main>
<footer class="footer">PLMun Lost &amp; Found Management System · School project prototype</footer>
<script src="<?= h(asset('assets/js/app.js')) ?>"></script>
</body>

</html>