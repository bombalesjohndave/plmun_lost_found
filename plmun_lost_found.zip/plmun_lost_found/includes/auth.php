<?php

declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

function require_login(): void
{
    if (empty($_SESSION['user_id'])) {
        header('Location: /plmun_lost_found/login.php');
        exit;
    }
}

function require_admin(): void
{
    require_login();

    if (($_SESSION['role'] ?? '') !== 'admin') {
        http_response_code(403);
        exit('Access denied.');
    }
}

function current_user_id(): int
{
    return (int)($_SESSION['user_id'] ?? 0);
}

function h(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . h(csrf_token()) . '">';
}

function verify_csrf(): void
{
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $submitted = $_POST['csrf_token'] ?? '';

        if (!is_string($submitted) || !hash_equals(csrf_token(), $submitted)) {
            http_response_code(419);
            exit('Your session token expired. Please go back, refresh the page, and try again.');
        }
    }
}

function notify_user(PDO $pdo, int $userId, string $title, string $body): void
{
    $stmt = $pdo->prepare('INSERT INTO notifications(user_id,title,body) VALUES(?,?,?)');
    $stmt->execute([$userId, $title, $body]);
}

function notify_admins(PDO $pdo, string $title, string $body): void
{
    $ids = $pdo->query("SELECT id FROM users WHERE role='admin' AND is_active=1")->fetchAll(PDO::FETCH_COLUMN);

    foreach ($ids as $id) {
        notify_user($pdo, (int)$id, $title, $body);
    }
}

function log_admin_action(PDO $pdo, string $action, string $type, int $id, string $details = ''): void
{
    $stmt = $pdo->prepare('INSERT INTO admin_activity_logs(admin_id,action,entity_type,entity_id,details) VALUES(?,?,?,?,?)');
    $stmt->execute([current_user_id(), $action, $type, $id, $details]);
}

function post_item_message(PDO $pdo, int $itemId, int $senderId, string $message): void
{
    $s = $pdo->prepare('SELECT id FROM chat_conversations WHERE item_report_id=? AND claim_id IS NULL ORDER BY id LIMIT 1');
    $s->execute([$itemId]);

    $cid = (int)$s->fetchColumn();

    if (!$cid) {
        $pdo->prepare('INSERT INTO chat_conversations(item_report_id,claim_id) VALUES(?,NULL)')->execute([$itemId]);
        $cid = (int)$pdo->lastInsertId();
    }

    $r = $pdo->prepare('SELECT reporter_id FROM item_reports WHERE id=?');
    $r->execute([$itemId]);

    $reporter = (int)$r->fetchColumn();

    $ids = $pdo->query("SELECT id FROM users WHERE role='admin' AND is_active=1")->fetchAll(PDO::FETCH_COLUMN);
    $ids[] = $reporter;

    $p = $pdo->prepare('INSERT IGNORE INTO chat_participants(conversation_id,user_id) VALUES(?,?)');

    foreach (array_unique(array_map('intval', $ids)) as $uid) {
        $p->execute([$cid, $uid]);
    }

    $pdo->prepare('INSERT INTO chat_messages(conversation_id,sender_id,message) VALUES(?,?,?)')->execute([$cid, $senderId, $message]);
}

function notify_once(PDO $pdo, int $userId, string $title, string $body): void
{
    $s = $pdo->prepare('SELECT id FROM notifications WHERE user_id=? AND title=? AND body=? AND is_read=0 LIMIT 1');
    $s->execute([$userId, $title, $body]);

    $id = (int)$s->fetchColumn();

    if ($id) {
        $pdo->prepare('UPDATE notifications SET created_at=NOW() WHERE id=?')->execute([$id]);
    } else {
        notify_user($pdo, $userId, $title, $body);
    }
}

function asset(string $path): string
{
    $file = __DIR__ . '/../' . $path;

    return '/plmun_lost_found/' . $path . '?v=' . (is_file($file) ? filemtime($file) : time());
}