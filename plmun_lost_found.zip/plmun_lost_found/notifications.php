
<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';

verify_csrf();
require_login();

$uid = current_user_id();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['action'] ?? '';
    $nid = (int)($_POST['id'] ?? 0);

    if ($act === 'mark_all') {
        $pdo->prepare('UPDATE notifications SET is_read=1 WHERE user_id=? AND is_read=0')->execute([$uid]);
    } elseif ($act === 'mark_read' && $nid > 0) {
        $pdo->prepare('UPDATE notifications SET is_read=1 WHERE id=? AND user_id=?')->execute([$nid, $uid]);
    } elseif ($act === 'delete' && $nid > 0) {
        $pdo->prepare('DELETE FROM notifications WHERE id=? AND user_id=?')->execute([$nid, $uid]);
    } elseif ($act === 'delete_all') {
        $pdo->prepare('DELETE FROM notifications WHERE user_id=?')->execute([$uid]);
    }

    $back = (string)($_POST['back'] ?? '');
    $dest = (strpos($back, '/plmun_lost_found/') === 0 && strpos($back, '//') === false) ? $back : 'notifications.php';
    header('Location: ' . $dest);
    exit;
}

$s = $pdo->prepare('SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC, id DESC LIMIT 100');
$s->execute([$uid]);
$rows = $s->fetchAll();

$hasUnread = (bool)array_filter($rows, fn($x) => !$x['is_read']);

$page_title = 'Notifications';

require __DIR__ . '/includes/header.php';
?>

<section class="page-heading">
     <a class="back-link" href="/plmun_lost_found/choose.php">← Back</a>
    <h1>Notifications</h1>
</section>

<?php if ($rows): ?>
    <div class="action-row">
        <?php if ($hasUnread): ?>
            <form method="post">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="mark_all">
                <button class="mini-btn">Mark all as read</button>
            </form>
        <?php endif; ?>

        <form method="post" data-confirm="Delete ALL notifications? This cannot be undone.">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="delete_all">
            <button class="mini-btn danger">Delete all</button>
        </form>
    </div>
<?php endif; ?>

<div class="list-grid">
    <?php foreach ($rows as $n): ?>
        <article class="card">
            <div class="row-between">
                <strong><?= h($n['title']) ?></strong>
                <?php if (!$n['is_read']): ?>
                    <span class="pill">Unread</span>
                <?php endif; ?>
            </div>
            <p><?= h($n['body']) ?></p>
            <small class="muted"><?= h($n['created_at']) ?></small>
            <div class="action-row" style="margin:10px 0 0">
                <?php if (!$n['is_read']): ?>
                    <form method="post">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="mark_read">
                        <input type="hidden" name="id" value="<?= (int)$n['id'] ?>">
                        <button class="mini-btn">Mark as read</button>
                    </form>
                <?php endif; ?>

                <form method="post" data-confirm="Delete this notification?">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" value="<?= (int)$n['id'] ?>">
                    <button class="mini-btn danger">Delete</button>
                </form>
            </div>
        </article>
    <?php endforeach; ?>

    <?php if (!$rows): ?>
        <div class="card empty">No notifications yet.</div>
    <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
