<?php

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';

verify_csrf();
require_login();

$uid = current_user_id();
$isAdmin = (($_SESSION['role'] ?? '') === 'admin');

$itemId = (int)($_GET['item_id'] ?? $_POST['item_id'] ?? 0);
$claimId = (int)($_GET['claim_id'] ?? $_POST['claim_id'] ?? 0);

$stmt = $pdo->prepare('SELECT * FROM item_reports WHERE id=?');
$stmt->execute([$itemId]);
$item = $stmt->fetch();

if (!$item) {
    http_response_code(404);
    exit('Item not found.');
}

$claim = null;

if ($claimId) {
    $stmt = $pdo->prepare('SELECT * FROM claims WHERE id=? AND item_report_id=?');
    $stmt->execute([$claimId, $itemId]);
    $claim = $stmt->fetch();

    if (!$claim) {
        http_response_code(404);
        exit('Claim not found.');
    }
}

$allowed = $isAdmin || (int)$item['reporter_id'] === $uid || ($claim && (int)$claim['claimant_id'] === $uid);

if (!$allowed) {
    http_response_code(403);
    exit('Not allowed.');
}

$stmt = $pdo->prepare('SELECT id FROM chat_conversations WHERE item_report_id=? AND ' . ($claimId ? 'claim_id=?' : 'claim_id IS NULL') . ' ORDER BY id LIMIT 1');
$stmt->execute($claimId ? [$itemId, $claimId] : [$itemId]);

$conversationId = (int)$stmt->fetchColumn();

if (!$conversationId) {
    $stmt = $pdo->prepare('INSERT INTO chat_conversations(item_report_id,claim_id) VALUES(?,?)');
    $stmt->execute([$itemId, $claimId ?: null]);
    $conversationId = (int)$pdo->lastInsertId();
}

$participants = [];

$admins = $pdo->query("SELECT id FROM users WHERE role='admin' AND is_active=1")->fetchAll(PDO::FETCH_COLUMN);

foreach ($admins as $a) {
    $participants[] = (int)$a;
}

if ($claim) {
    $participants[] = (int)$claim['claimant_id'];

    if ($item['custody_status'] === 'Reporter') {
        $participants[] = (int)$item['reporter_id'];
    }
} else {
    $participants[] = (int)$item['reporter_id'];
}

foreach (array_unique($participants) as $pid) {
    $st = $pdo->prepare('INSERT IGNORE INTO chat_participants(conversation_id,user_id) VALUES(?,?)');
    $st->execute([$conversationId, $pid]);
}

$st = $pdo->prepare('SELECT 1 FROM chat_participants WHERE conversation_id=? AND user_id=?');
$st->execute([$conversationId, $uid]);

if (!$st->fetchColumn()) {
    http_response_code(403);
    exit('Not a participant.');
}

$chatBody = 'You received a message about item #' . $itemId . ($claimId ? ' (Claim #' . $claimId . ')' : '');

$pdo->prepare("UPDATE notifications SET is_read=1 WHERE user_id=? AND title='New chat message' AND body=? AND is_read=0")->execute([$uid, $chatBody]);

function chat_messages(PDO $pdo, int $cid, int $after): array
{
    $s = $pdo->prepare('SELECT m.id,m.sender_id,m.message,m.sent_at,u.full_name FROM chat_messages m JOIN users u ON u.id=m.sender_id WHERE m.conversation_id=? AND m.id>? ORDER BY m.id ASC');
    $s->execute([$cid, $after]);

    return $s->fetchAll();
}

if (isset($_GET['poll'])) {
    header('Content-Type: application/json');

    $after = max(0, (int)($_GET['after'] ?? 0));

    echo json_encode(chat_messages($pdo, $conversationId, $after), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['message'])) {
    $message = trim($_POST['message']);

    if ($message === '' || strlen($message) > 4000) {
        $error = 'Message must contain 1 to 4,000 characters.';
    } else {
        $st = $pdo->prepare('INSERT INTO chat_messages(conversation_id,sender_id,message) VALUES(?,?,?)');
        $st->execute([$conversationId, $uid, $message]);

        $recipientIds = array_values(array_diff(array_unique($participants), [$uid]));

        foreach ($recipientIds as $rid) {
            notify_once($pdo, $rid, 'New chat message', $chatBody);
        }

        header('Location: chat.php?item_id=' . $itemId . ($claimId ? '&claim_id=' . $claimId : ''));
        exit;
    }
}

$messages = chat_messages($pdo, $conversationId, 0);
$lastId = $messages ? (int)end($messages)['id'] : 0;

$page_title = 'Item conversation';

require __DIR__ . '/includes/header.php';
?>

<div class="narrow">
    <a class="back-link" href="<?= $isAdmin ? 'admin/claims.php' : ((int)$item['reporter_id'] === $uid ? 'reporter/dashboard.php' : 'claimant/dashboard.php') ?>">
        ← Back
    </a>

    <section class="card">
        <span class="eyebrow">ITEM CONVERSATION</span>

        <h1><?= h($item['item_name']) ?></h1>

        <p class="muted">
            Item #<?= $itemId ?><?= $claimId ? ' · Claim #' . $claimId : '' ?> · Messages refresh automatically while this page is open.
        </p>

        <?php if ($error): ?>
            <div class="alert error"><?= h($error) ?></div>
        <?php endif; ?>

        <div class="chat-messages" id="chatMessages" aria-live="polite">
            <?php if (!$messages): ?>
                <p class="muted center">No messages yet. Start the conversation below.</p>
            <?php endif; ?>

            <?php foreach ($messages as $m): ?>
                <div class="chat-message <?= (int)$m['sender_id'] === $uid ? 'mine' : '' ?>" data-message-id="<?= (int)$m['id'] ?>">
                    <strong><?= h($m['full_name']) ?></strong>

                    <p><?= nl2br(h($m['message'])) ?></p>

                    <small><?= h($m['sent_at']) ?></small>
                </div>
            <?php endforeach; ?>
        </div>

        <form method="post" class="chat-compose">
            <?= csrf_field() ?>

            <input type="hidden" name="item_id" value="<?= $itemId ?>">
            <input type="hidden" name="claim_id" value="<?= $claimId ?>">

            <textarea name="message" rows="2" maxlength="4000" required placeholder="Write a message..."></textarea>

            <button class="btn">Send</button>
        </form>
    </section>
</div>

<script>
    (() => {
        const box = document.getElementById('chatMessages');
        let last = <?= $lastId ?>;

        const endpoint = new URL(window.location.href);
        endpoint.searchParams.set('poll', '1');

        const esc = s => String(s).replace(/[&<>"']/g, c => ({
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#39;'
        } [c]));

        async function poll() {
            try {
                const u = new URL(endpoint);
                u.searchParams.set('after', last);

                const r = await fetch(u, {
                    headers: {
                        'Accept': 'application/json'
                    }
                });
                if (!r.ok) return;
                const rows = await r.json();
                for (const m of rows) {
                    const el = document.createElement('div');

                    el.className = 'chat-message ' + (Number(m.sender_id) === <?= $uid ?> ? 'mine' : '');
                    el.dataset.messageId = m.id;

                    el.innerHTML = '<strong>' + esc(m.full_name) + '</strong><p>' + esc(m.message).replace(/\n/g, '<br>') + '</p><small>' + esc(m.sent_at) + '</small>';

                    box.appendChild(el);
                    last = Math.max(last, Number(m.id));
                }
                if (rows.length) {
                    box.scrollTop = box.scrollHeight;
                }
            } catch (e) {}
        }
        box.scrollTop = box.scrollHeight;
        setInterval(poll, 2500);
    })();
</script>

<?php require __DIR__ . '/includes/footer.php'; ?>